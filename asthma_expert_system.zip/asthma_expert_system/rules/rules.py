rules = [

    # =======================================================
    # 1. CHẨN ĐOÁN SƠ BỘ HEN PHẾ QUẢN
    # =======================================================
    {
        "id": "L1",
        "if": lambda f: (
            sum([f["f101"]["value"], f["f102"]["value"], f["f103"]["value"], f["f104"]["value"]]) >= 2
            and (f["f105"]["value"] or f["f106"]["value"] or f["f107"]["value"])
        ),
        "then": ["f501", "f503"],   
        "desc": "≥2 triệu chứng chính & thay đổi theo thời gian → Nghi ngờ HPQ"
    },

    # =======================================================
    # 2. CHẨN ĐOÁN XÁC ĐỊNH DỰA TRÊN CẬN LÂM SÀNG
    # =======================================================
    {
        "id": "L2",
        "if": lambda f: (
            f["f201"]["value"] or   # FEV1/FVC thấp
            f["f202"]["value"] or   # FEV1 tăng ≥12% & ≥200ml
            f["f203"]["value"]      # PEF biến thiên >10%
        ),
        "then": ["f502"],
        "desc": "Test phổi dương tính → Rối loạn thông khí tắc nghẽn biến đổi"
    },

    {
        "id": "L3",
        "if": lambda f: f["f501"]["value"] and f["f502"]["value"],
        "then": ["f504"],
        "desc": "Thỏa L1 và L2 → Chẩn đoán HPQ xác định"
    },

    # L4: Dành cho bệnh nhân đã dùng ICS/LABA
    {
        "id": "L4",
        "if": lambda f: (
            (f["f301"]["value"] or f["f302"]["value"]) and
            (f["f101"]["value"] or f["f102"]["value"] or f["f103"]["value"] or f["f104"]["value"]) and
            (f["f204"]["value"] or f["f205"]["value"])
        ),
        "then": ["f504"],
        "desc": "Đang dùng ICS/LABA nhưng còn triệu chứng + test dương → HPQ xác định"
    },

    # =======================================================
    # 3. PHÂN BIỆT CHẨN ĐOÁN VỚI CÁC BỆNH KHÁC
    # =======================================================

    # COPD
    {
        "id": "L5-1",
        "if": lambda f: (
            f["f401"]["value"] and   # hút thuốc
            f["f115"]["value"] and   # ho khạc đờm mạn
            f["f201"]["value"] and   # FEV1/FVC thấp
            not f["f204"]["value"]   # không hồi phục sau test giãn
        ),
        "then": ["f509"],
        "desc": "Hút thuốc + ho mạn + FEV1/FVC thấp không hồi phục → COPD"
    },

    # Suy tim
    {
        "id": "L5-2",
        "if": lambda f: f["f103"]["value"] and f["f111"]["value"] and f["f405"]["value"],
        "then": ["f510"],
        "desc": "Khó thở + ran ẩm + tiền sử THA/Suy tim → Suy tim trái"
    },

    # Hẹp / u / dị vật
    {
        "id": "L5-3",
        "if": lambda f: f["f103"]["value"] and f["f112"]["value"] and f["f113"]["value"],
        "then": ["f511"],
        "desc": "Khó thở + tiếng rít cố định + không đáp ứng giãn PQ → Hẹp/U/Dị vật"
    },

    # GERD / rò khí-thực quản
    {
        "id": "L5-4",
        "if": lambda f: f["f114"]["value"],
        "then": ["f512"],
        "desc": "Ho/khó thở tăng khi nằm/ăn → GERD hoặc rò khí – thực quản"
    },

    # Giãn phế quản
    {
        "id": "L5-5",
        "if": lambda f: f["f115"]["value"],
        "then": ["f513"],
        "desc": "Ho đờm mủ nhiều năm → Giãn phế quản"
    },

    # =======================================================
    # 4. KIỂM SOÁT & ĐIỀU TRỊ HEN
    # =======================================================
    
    # Hen không kiểm soát → tăng bậc điều trị
    {
        "id": "L6",
        "if": lambda f: (
            f["f116"]["value"] and
            f["f117"]["value"] and
            f["f118"]["value"]
        ),
        "then": ["f506", "f507"],
        "desc": "≥3 triệu chứng không kiểm soát → Hen không kiểm soát, tăng bậc"
    },

    # Hen kiểm soát tốt → giảm bậc điều trị
    {
        "id": "L7",
        "if": lambda f: (
            not f["f116"]["value"] and
            not f["f117"]["value"] and
            f["f119"]["value"]
        ),
        "then": ["f505", "f508"],
        "desc": "Hen kiểm soát tốt >=3 tháng → Giảm bậc điều trị"
    }
]
