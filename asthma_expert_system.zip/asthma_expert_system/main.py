from facts.facts import facts
from rules.rules import rules
from engine.wm import WorkingMemory
from utils.helpers import input_boolean, input_float

def main():
    wm = WorkingMemory(facts)
    wm.reset()

    print("=== Nhập dữ liệu bệnh nhân ===")

    # ---------- Triệu chứng chính (f101-f104) ----------
    wm.set("f101", input_boolean("Ho, kéo dài hoặc từng cơn?"))
    wm.set("f102", input_boolean("Khò khè khi thở ra?"))
    wm.set("f103", input_boolean("Khó thở / thở gấp?"))
    wm.set("f104", input_boolean("Cảm giác nặng ngực?"))

    # ---------- Triệu chứng thay đổi (f105-f107) ----------
    wm.set("f105", input_boolean("Triệu chứng thay đổi theo thời gian / có triggers?"))
    wm.set("f106", input_boolean("Triệu chứng nặng hơn về đêm?"))
    wm.set("f107", input_boolean("Triệu chứng nặng khi gắng sức?"))

    # ---------- Kiểm tra L1: Chẩn đoán sơ bộ hen ----------
    main_symptoms_count = sum([wm.get(f) for f in ["f101","f102","f103","f104"]])
    if main_symptoms_count >= 2 and (wm.get("f105") or wm.get("f106") or wm.get("f107")):
        print("✔ Thỏa L1: thêm f501, f503 vào WM")
        wm.set("f501", True)
        wm.set("f503", True)
        # ---------- Bước L2: Xét nghiệm ----------
        fev1_fvc = input_float("Nhập FEV1/FVC (ví dụ 0.74)", allow_empty=True)
        if fev1_fvc is not None and fev1_fvc < 0.75:
            wm.set("f201", True)
        fev1_increase_pct = input_float("Nhập FEV1 tăng sau giãn (%) (ví dụ 12)", allow_empty=True)
        if fev1_increase_pct is not None and fev1_increase_pct >= 12:
            wm.set("f202", True)
        pef_var = input_float("Nhập biến thiên PEF (%) nếu có (ví dụ 10)", allow_empty=True)
        if pef_var is not None and pef_var > 10:
            wm.set("f203", True)
        wm.set("f204", input_boolean("Test hồi phục phế quản dương tính?"))
        wm.set("f205", input_boolean("Test kích thích phế quản dương tính?"))

        # L2 kiểm tra
        if wm.get("f201") or wm.get("f202") or wm.get("f203"):
            print("✔ Thỏa L2: thêm f502 vào WM")
            wm.set("f502", True)
        else:
            print("⚠ Có thể là hen, cần thêm xét nghiệm để chắc chắn")

        # L3: Chẩn đoán xác định hen
        if wm.get("f501") and wm.get("f502"):
            print("✔ Thỏa L3: thêm f504 vào WM (Hen xác định)")
            wm.set("f504", True)
        else:
            print("⚠ Chưa đủ dữ liệu để chẩn đoán hen chắc chắn")

        # L4: Kiểm tra mức độ kiểm soát & điều trị
        wm.set("f301", input_boolean("Đang dùng ICS?"))
        wm.set("f302", input_boolean("Đang dùng LABA?"))
        if (wm.get("f301") or wm.get("f302")) and any([wm.get(f) for f in ["f101","f102","f103","f104"]]) and (wm.get("f204") or wm.get("f205")):
            print("✔ Thỏa L4: Hen xác định (f504=True)")
            wm.set("f504", True)

        # L6/L7: Kiểm soát
        wm.set("f116", input_boolean("Triệu chứng ban ngày thường xuyên?"))
        wm.set("f117", input_boolean("Tỉnh giấc ban đêm?"))
        wm.set("f118", input_boolean("Tăng dùng thuốc cắt cơn?"))
        wm.set("f119", input_boolean("Ổn định ≥3 tháng?"))

        if wm.get("f116") and wm.get("f117") and wm.get("f118"):
            print("✔ Thỏa L6: Hen không kiểm soát, cần tăng bậc điều trị (f506, f507)")
            wm.set("f506", True)
            wm.set("f507", True)
        elif not wm.get("f116") and not wm.get("f117") and wm.get("f119"):
            print("✔ Thỏa L7: Hen kiểm soát tốt, giảm bậc điều trị (f505, f508)")
            wm.set("f505", True)
            wm.set("f508", True)

    else:
        print("✖ Không đủ thông tin để kết luận hen phế quản → Có thể là bệnh khác, kiểm tra L5-x")

        # ---------- Bước L5-x: Phân biệt bệnh khác ----------
        wm.set("f401", input_boolean("Tiền sử hút thuốc?"))
        wm.set("f404", input_boolean("Tiền sử COPD?"))
        wm.set("f405", input_boolean("Tiền sử suy tim trái / THA?"))
        wm.set("f115", input_boolean("Ho khạc đờm mủ nhiều năm?"))
        wm.set("f111", input_boolean("Có ran ẩm?"))
        wm.set("f103", input_boolean("Khó thở / thở gấp?"))
        wm.set("f112", input_boolean("Tiếng rít cố định?"))
        wm.set("f113", input_boolean("Không đáp ứng giãn phế quản?"))
        wm.set("f114", input_boolean("Ho/khó thở tăng khi nằm/ăn uống?"))

        # Kiểm tra từng luật L5-x
        if wm.get("f401") and wm.get("f115") and wm.get("f201") and not wm.get("f204"):
            wm.set("f509", True)
            print("🚨 Nghi COPD")
        if wm.get("f103") and wm.get("f111") and wm.get("f405"):
            wm.set("f510", True)
            print("🚨 Nghi suy tim trái")
        if wm.get("f103") and wm.get("f112") and wm.get("f113"):
            wm.set("f511", True)
            print("🚨 Nghi Hẹp/U/Dị vật PQ")
        if wm.get("f114"):
            wm.set("f512", True)
            print("🚨 Nghi GERD / rò khí thực quản")
        if wm.get("f115"):
            wm.set("f513", True)
            print("🚨 Nghi Giãn phế quản")

    print("\n========================")
    print("🏁 KẾT LUẬN CUỐI CÙNG")
    print("========================")
    if wm.get("f504"):
        print(" - Hen phế quản: Xác định")
    elif any([wm.get(f) for f in ["f509","f510","f511","f512","f513"]]):
        print(" - Không đủ dữ liệu hen, nhưng có thể là bệnh khác")
    else:
        print(" - Chưa đủ dữ liệu để đưa ra kết luận rõ ràng")

if __name__ == "__main__":
    main()
